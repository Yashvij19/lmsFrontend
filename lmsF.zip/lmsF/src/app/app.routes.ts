import { Routes } from '@angular/router';
import { HomeComponent } from './components/main/home/home.component';
import { DashboardhomeComponent } from './components/dashboard/dashboardhome/dashboardhome.component';
import { AddLobComponent } from './components/dashboard/add-lob/add-lob.component';
import { ViewLobComponent } from './components/dashboard/view-lob/view-lob.component';
import { AddSmeComponent } from './components/dashboard/add-sme/add-sme.component';
import { ViewSmeComponent } from './components/dashboard/view-sme/view-sme.component';
import { AddCategoryComponent } from './components/dashboard/add-category/add-category.component';
import { ViewCategoryComponent } from './components/dashboard/view-category/view-category.component';
import { AddCourseComponent } from './components/dashboard/add-course/add-course.component';


export const routes: Routes = [
    {path: '', component:HomeComponent},

    { path: 'dashboard',component:DashboardhomeComponent , children: [
        { path: 'lob/add', component: AddLobComponent },
        {path: 'lob/view', component:ViewLobComponent },
        { path: 'sme/add', component: AddSmeComponent },
        {path: 'sme/view', component:ViewSmeComponent },
        {path: 'course/addCategory',component:AddCategoryComponent },
        {path: 'course/viewCategory',component:ViewCategoryComponent },
        
     ] }
];
