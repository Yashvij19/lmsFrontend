import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-lob',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-lob.component.html',
  styleUrls: ['./add-lob.component.css']
})
export class AddLobComponent implements OnInit {
  lobForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.initForm();
  }

  initForm(): void {
    this.lobForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  onCancel(): void {
    // Reset form or navigate back
    this.lobForm.reset();
  }

  onSave(): void {
    if (this.lobForm.valid) {
      // Handle form submission
      console.log('LOB data:', this.lobForm.value);
      // Here you would typically call a service to save the data
      this.lobForm.reset();
    } else {
      // Mark all fields as touched to trigger validation messages
      Object.keys(this.lobForm.controls).forEach(key => {
        const control = this.lobForm.get(key);
        control?.markAsTouched();
      });
    }
  }
}